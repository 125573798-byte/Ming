# 智慧进销存 · Cloudflare 部署与云备份指南

本目录已把原程序改写为 **Cloudflare Pages（静态前端）+ Pages Functions（备份接口）+ R2（快照存储）** 架构。

```
智慧进销存-Cloudflare部署包/
├── public/
│   └── index.html              ← 改写好编码后的前端（UTF-8 无 BOM）
├── functions/
│   └── api/
│       └── [[route]].js        ← Pages Function：/api/backup/upload|latest|list|download|delete
├── docs/
│   └── 部署教程.md              ← 本文（手机端详细步骤）
├── _headers                    ← 缓存策略 + 安全头
├── _redirects                  ← SPA 回退
├── wrangler.toml               ← Wrangler CLI 配置（可选）
└── package.json                ← 含 deploy / dev 脚本（可选）
```

## 一、准备工作（手机即可完成）

1. **Cloudflare 账号**：https://dash.cloudflare.com 注册（免费套餐足够）。
2. **GitHub 账号**：https://github.com 注册（存放代码，触发自动部署）。
3. **手机工具**（三选一）：
   - **Working Copy**（iOS）／**Termux + Git**（Android）：可克隆、推送。
   - **GitHub Mobile**：可新建仓库、上传、编辑文件。
   - **电脑网页端**：更省力，但全程手机亦可完成。

> 免费额度（2026）：Pages 每月 500 构建分钟、请求不限；R2 每月 10 GB 存储、100 万次 A 类操作。进销存快照通常 < 1 MB，完全够用。

## 二、方式 A：GitHub 联动部署（推荐，推送即发布）

### 第 1 步：把本部署包上传到 GitHub

1. 打开 https://github.com/new ，新建仓库，名如 `inventory-app`，选 **Public**（私有仓库 Pages 构建需付费）。
2. 进入仓库 → **Upload files** → 上传本包内容，保证存在：
   - `public/index.html`
   - `functions/api/[[route]].js`
   - `_headers`、`_redirects`
3. 提交（`Commit changes`）。

> GitHub 网页端不支持一次传整个文件夹层级，建议用 Working Copy，或把 `public/`、`functions/` 分别拖入。

### 第 2 步：Cloudflare 连接 GitHub

1. Cloudflare 仪表盘 → 左侧 **Compute(Workers)** → **Pages** → **Create a project** → **Connect to Git**。
2. 授权 GitHub，选中 `inventory-app`。
3. 构建配置：
   - Framework preset：**None**
   - Build command：留空（或 `echo skip`）
   - Build output directory：`public`
4. 点 **Save and Deploy**，约 30–90 秒后得到地址 `https://inventory-app.pages.dev`（子域名可自定义）。

> 此后每次 `git push`，Cloudflare 自动重新部署。

### 第 3 步：绑定 R2 存储桶

1. 仪表盘 → **R2 Object Storage** → **Create bucket**，命名 `inventory-backup`。
2. 回到 Pages 项目 → **Settings** → **Functions** → **R2 bucket bindings** → **Add binding**：
   - Variable name：`R2_BUCKET`（必须与 `[[route]].js` 里 `env.R2_BUCKET` 一致）
   - Bucket：选 `inventory-backup`
3. 保存。

### 第 4 步：设置访问令牌

Pages 项目 → **Settings** → **Environment variables** → **Add variable**：

| Variable name | Value |
|---|---|
| `BACKUP_TOKEN` | 自定 16 位以上强随机串，如 `x9Kp!vL2@sQ7#mZ3` |

App 云备份页的“访问令牌”填**完全一致**的值。

> 用 Wrangler CLI 可改为 `wrangler secret put BACKUP_TOKEN --env production`，避免明文进仓库。

### 第 5 步：在 App 里填云端地址

1. 手机浏览器打开 `https://inventory-app.pages.dev`，进入 **设置 / 云端备份**。
2. 云端地址：`https://inventory-app.pages.dev/api`
3. 访问令牌：第 4 步的 `BACKUP_TOKEN`。
4. 开启“自动备份”，间隔建议 **30 分钟**（仅前台且联网时触发）。
5. 点 **连接测试** → “云端空闲/正常” → **立即备份** → 完成第一条快照。

## 三、方式 B：Wrangler 命令行部署

```bash
cd 智慧进销存-Cloudflare部署包
npx wrangler login
npx wrangler r2 bucket create inventory-backup
npx wrangler secret put BACKUP_TOKEN --env production
npx wrangler pages deploy public --project-name inventory-app
```

本地预览：`npx wrangler pages dev public --port 8788`。

## 四、自动备份 & 恢复备份

### 自动备份
- 开关：**设置 → 云端备份 → 自动备份**。开启后，页面前台且联网时每 N 分钟生成快照上传 R2。
- 快照内容：商品 / 批次 / 拆分 / 销售 / 挂单 / 供应商 / 采购 + 店铺设置。
- **图片不进云端**（仅保留引用），以控制体积；换设备/清缓存后商品图会丢失，属预期。
- 云端仅保留**最近 30 条**，超出自动删最旧。
- 清单、上传时间、大小可在“云端备份”页查看。

### 恢复备份
1. **恢复到最新**：云端备份页 → **恢复最新快照** → 确认。会清空本地 7 张表后重写，**不可撤销**，建议先“导出文本”留底。
2. **恢复到指定版本**：快照列表点某条 → 预览 → 恢复。适合“误删商品后回滚到昨天”。
3. **误恢复补救**：R2 保留 30 条历史，可挑恢复前的那条再恢复；**不要在误操作后立刻手动备份**，否则会冲掉旧快照。
4. **换手机迁移**：新手机打开同一地址 → 填相同端点与令牌 → “恢复最新快照”。

### 应急：直接操作 R2
仪表盘 → R2 → `inventory-backup` → `inventory-snapshots/` 下载 `.json` 快照，结构为 `{ meta, payload: { products, batches, splits, sales, held, suppliers, purchases } }`。

## 五、故障排查

| 现象 | 原因 | 处理 |
|---|---|---|
| 连接失败 / CORS | 端点漏 `https://` 或多斜杠 | 必须为 `https://xxx.pages.dev/api` |
| 401 令牌不正确 | 两端不一致 | 重新核对，注意空格 |
| 500 R2_BUCKET 未绑定 | 忘了 R2 绑定 | Settings → Functions → R2 bucket bindings |
| 恢复为空 | 快照非本程序生成 | 只用本程序快照恢复 |
| 快照越来越大 | 记录过多 | 定期“导出文本”归档，或改 `[[route]].js` 中 `30` |
| 图片不显示 | 预期行为 | 图片在 IndexedDB，未上传 |
| 白屏 | Pages 构建失败 | 看 Deployments 日志，通常缺 `public/index.html` |
| 内地访问慢 | 边缘节点 | 开 Cloudflare 代理，或等冷启动 |

## 六、安全与费用

1. **令牌即权限**：`BACKUP_TOKEN` 等同“可读取/覆盖全部数据”，勿泄露、勿写进前端。
2. 建议开启 **Security → WAF → Rate Limiting**，对 `/api/backup/*` 限流（如每 IP 每分钟 10 次）。
3. 建议 **SSL/TLS → 始终 HTTPS**；**Speed → Auto Minify（HTML/CSS/JS）**。
4. 费用：正常使用接近 0。R2 超 10 GB 才计费；本版已排除图片 base64，不会异常膨胀。
5. 数据主权：快照在 R2，可随时导出；删 Pages 项目不自动删 R2 桶，需手动清理。

---
生成时间：2026-10-07
前端：public/index.html（UTF-8 无 BOM）
后端：functions/api/[[route]].js（Pages Functions + R2）
